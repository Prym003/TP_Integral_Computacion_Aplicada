history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
apt update
ping -c 3 8.8.8.8
poweroff
ip addr
echo "auto enp0s1 iface enp0s1 inet dhcp" >> /etc/network/interfaces
ip addr
ifup enp0s1
cat /etc/network/interfaces
sed -i '/auto enp0s iface/d' /etc/network/interfaces
sed -i 's/enp0s3/enp0s1/g' /etc/network/interfaces
cat /etc/network/interfaces
grep -v "auto enp0s1 iface" /etc/network/interfaces > /tmp/int.tmp && mv /tmp/init.tmp /etc/network/interfaces
grep -v "auto enp0s1 iface" /etc/network/interfaces > /tmp/int.tmp && mv /tmp/int.tmp /etc/network/interfaces
dhclient enp0s1
ip addr show enp0s1
ping -c 3 8.8.8.8
apt update 
echo "nameserver 8.8.8.8" > /etc/resolv.conf
apt update 
cat /etc/resolv.conf
ping -c 1 google.com
apt update
cat /etc/apt/sources.list
cat > /etc/apt/sources.list >>
cat > /etc/apt/sources.list << 'EOF'


cat /etc/apt/sources.list
sed -i 's/cdn2-fastly.deb.debian.org/deb.debian.org/g' /etc/apt/sources.list
sed -i 's/bullseye/bookworm/g' etc/apt/sources.list
sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list
cat /etc/apt/sources.list
sed -i 's|cdn2-fastly.deb.debian.org/|security.debian.org/debian-security|g' /etc/apt/sources.list
cat /etc/apt/sources.list
echo [
echo "deb http://deb.debian.org/debian bookworm main contriob non-free" > /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bookworm-updates main contriob non-free" >> /etc/apt/sources.list
echo "deb http://security.debian.org/debian-security bookworm-security main contriob non-free" >> /etc/apt/sources.list
cat /etc/apt/sources.list
sed -i 's/contriob/contrib/g' /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt full-upgrade -y
reboot
cat /etc/os-release
ping -c 1 google.com 
apt install openssh-server -y 
systemctls status ssh
systemctl status ssh
mkdir -p /root/.ssh
chmod 700 /root/.ssh
poweroff
chmod 600 ~/UniversidadPalermo/Computacion_Aplicada/TP_intergador/clave_privada.txt
sed -i 's/PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
sed -i 's/PermitRootLogin yes/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
systemctl restart ssh
cp /root/.ssh/authorized_keys /root/clave_publica.pub
ls /root/
tar tzf Material_Adicional_TPVMCA.tar.gz
tar xzf Material_Adicional_TPVMCA.tar.gz -C /root/ --strip-components=1
ls /root/
apt install apache2 php libapache2-mod-php -y
systemctl status apache2
cp /root/index.php /var/www/html/
cp /root/logo.png /var/www/html/
ls /var/www/html/
php -v
apt install mariadb-server -y
systemctl status mariadb
mariadb < /root/db.sql
mariadb -e "SHOW DATABASES;"
ip route
echo "source /etc/network/interfaces.d/*" > /etc/network/interfaces
echo "" >> /etc/network/interfaces
echo "auto lo" >> /etc/network/interfaces
echo "iface lo inet loopback" >> /etc/network/interfaces
echo "" >> /etc/network/interfaces
echo "auto enp0s1" >> /etc/network/interfaces
echo "iface enp0s1 inet static" >> /etc/network/interfaces
echo "    address 192.168.64.7" >> /etc/network/interfaces
echo "    netmask 255.255.255.0" >> /etc/network/interfaces
echo "    gateway 192.168.64.1" >> /etc/network/interfaces
cat /etc/network/interfaces
systemctl restart networking
ip addr show enp0s1
exit
grep -E "PermitRootLogin|PasswordAuthentication" /etc/ssh/sshd_config
sed -i "s/#PermitRootLogin prohibit-password/PermitRootLogin yes/" /etc/ssh/sshd_config
sed -i "s/#PasswordAuthentication yes/PasswordAuthentication yes/" /etc/ssh/sshd_config
systemctl restart ssh
sed -i "s/#PasswordAuthentication yes/PasswordAuthentication yes/" /etc/ssh/sshd_config
grep -E "PermitRootLogin|PasswordAuthentication" /etc/ssh/sshd_config
ip addr show enp0s1
exit
poweroff
lsblk
fdisk /dev/vda
mkfs.ext4 /dev/vda1
mkfs.ext4 /dev/vda2
mkdir -p /www_dir
mkdir -p /backup_dir
mount /dev/vda1 /www_dir
mount /dev/vda2 /backup_dir
lsblk
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
sed -i 's|/var/www/html|/www_dir|g' /etc/apache2/sites-available/000-default.conf
sed -i 's|/var/www/html|/www_dir|g' /etc/apache2/apache2.conf
systemctl restart apache2
ls /www_dir/
grep -r "DocumentRoot" /etc/apache2/sites-available/000-default.conf
echo "/dev/vda1  /www_dir    ext4  defaults  0  2" >> /etc/fstab
echo "/dev/vda2  /backup_dir ext4  defaults  0  2" >> /etc/fstab
cat /etc/fstab
cat /proc/partitions > /opt/particion
cat /opt/particion
reboot
