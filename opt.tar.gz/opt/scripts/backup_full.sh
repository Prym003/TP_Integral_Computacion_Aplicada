#!/bin/bash

if [ "$1" = "-help" ]; then
  echo "Uso: backup_full.sh <origen> <destino>"
  echo "Ejemplo: backup_full.sh /var/log /backup_dir"
  exit 0
fi

if [ -z "$1" ] || [ -z "$2" ]; then
  echo "Error: se requieren origen y destino. Use -help."
  exit 1
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")

if [ ! -d "$ORIGEN" ]; then
  echo "Error: el directorio origen $ORIGEN no existe."
  exit 1
fi

if [ ! -d "$DESTINO" ]; then
  echo "Error: el directorio destino $DESTINO no existe."
  exit 1
fi

tar czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"
echo "Backup completado: ${NOMBRE}_bkp_${FECHA}.tar.gz"
